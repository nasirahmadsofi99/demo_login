//
//  UIView.swift
//  Mint
//
//  Created by Aqib Ali on 13/07/19.
//  Copyright © 2019 Aqib Ali. All rights reserved.
//

import UIKit
extension UIView{
    
    @IBInspectable var borderColor:UIColor? {
        set {
            layer.borderColor = newValue!.cgColor
        }
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            else {
                return nil
            }
        }
    }
    
    @IBInspectable var borderWidth:CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    
    @IBInspectable var cornerRadius:CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
    
    @IBInspectable var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable var shadowColor:UIColor? {
        set {
            layer.shadowColor = newValue!.cgColor
        }
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            else {
                return nil
            }
        }
    }
    
    @IBInspectable var circle:CGFloat {
        set {
            layer.cornerRadius = newValue > 0 ? frame.size.height * 0.5 : 0
        }
        get {
            return layer.cornerRadius
        }
    }
    
    
}

//MARK:- Additional
extension UIView{
    
    @discardableResult
    func gradient(colors:Array<CGColor>,start:CGPoint,end:CGPoint) -> CAGradientLayer{
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = colors
        gradientLayer.frame = bounds
        gradientLayer.startPoint = start
        gradientLayer.endPoint = end
        layer.insertSublayer(gradientLayer, at: 0)
        //        gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
        //        gradientLayer.endPoint = CGPoint(x: 1, y: 0.5)
        return gradientLayer
        
    }
    
    func round(){
        layoutIfNeeded()
        layer.cornerRadius = frame.height * 0.5
        clipsToBounds = true
    }
    
    func vibrate() {
        let shake: CABasicAnimation = CABasicAnimation(keyPath: "position")
        shake.duration = 0.07
        shake.repeatCount = 3
        shake.autoreverses = true
        shake.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 10, y: self.center.y))
        shake.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 10, y: self.center.y))
        layer.add(shake, forKey: "position")
    }
}

//MARK:- FOR XIBS
extension UIView{
    func fill(_ container: UIView!) -> Void{
        self.translatesAutoresizingMaskIntoConstraints = false;
        self.frame = container.frame
        container.addSubview(self)
        leadingAnchor.constraint(equalTo: container.leadingAnchor).isActive = true
        trailingAnchor.constraint(equalTo: container.trailingAnchor).isActive = true
        topAnchor.constraint(equalTo: container.topAnchor).isActive = true
        bottomAnchor.constraint(equalTo: container.bottomAnchor).isActive = true
    }
}

//MARK:- CONSTRAINTS
extension UIView{
    func fillSuperview(padding:CGFloat = 0) {
        guard let superview = superview else {
            return
        }
        translatesAutoresizingMaskIntoConstraints = false
        leadingAnchor.constraint(equalTo: superview.leadingAnchor, constant: padding).isActive = true
        trailingAnchor.constraint(equalTo: superview.trailingAnchor, constant: padding).isActive = true
        topAnchor.constraint(equalTo: superview.topAnchor, constant: padding).isActive = true
        bottomAnchor.constraint(equalTo: superview.bottomAnchor, constant: padding).isActive = true
    }
}
//MARK:- IMAGE
var imagecache = NSCache<NSString,UIImage>()
extension UIView{
    func image(iv:UIImageView,urlString:String?){
        iv.image = nil
        DispatchQueue.global(qos: .userInteractive).async {
            
            guard let urlString = urlString else{
                self.setImage(iv:iv,image: nil)
                return
            }
            
            if let img = imagecache.object(forKey: NSString(string:urlString)) {
                self.setImage(iv:iv,image: img)
                return
            }
            
            guard let url = URL.init(string:  urlString) else{
                self.setImage(iv:iv,image: nil)
                return
            }
            
            guard let data = try? Data(contentsOf: url) else {
                self.setImage(iv:iv,image: nil)
                return
            }
            
            guard let image = UIImage(data: data) else{
                self.setImage(iv:iv,image: nil)
                return
            }
            imagecache.setObject(image, forKey: NSString(string: urlString))
            self.setImage(iv:iv,image: image)
        }
    }
    
    func setImage(iv:UIImageView,image:UIImage?) {
        DispatchQueue.main.async {
            iv.image = image ?? UIImage(named: "broken_image")
        }
    }
}












@IBDesignable
extension UITextField {
    
    @IBInspectable var rightAccessory: UIImage? {
        set {
            if newValue != nil {
                let iv = UIImageView(frame: CGRect(x: 16, y: 8, width: 24, height: 24))
                iv.image = newValue
                iv.contentMode = .scaleAspectFit
                let viewRight: UIView = UIView(frame: CGRect.init(x: 0, y: 0, width: 56, height: 40))// set per your requirement
                viewRight.addSubview(iv)
                rightViewMode = .always
                rightView = viewRight
            } else {
                rightViewMode = .never
                rightView = nil
            }
        }
        get {
            if let imageView = self.rightView as? UIImageView {
                return imageView.image
            } else {
                return nil
            }
        }
    }
    
    @IBInspectable var leftAccessary: UIImage? {
        set {
            if newValue != nil {
                let iv = UIImageView(frame: CGRect(x: 16, y: 8, width: 24, height: 24))
                iv.image = newValue
                iv.contentMode = .scaleAspectFit
                let viewLeft: UIView = UIView(frame: CGRect.init(x: 0, y: 0, width: 56, height: 40))// set per your requirement
                viewLeft.addSubview(iv)
                self.leftView = viewLeft
                self.leftViewMode = .always
            } else {
                leftViewMode = .never
                leftView = nil
            }
        }
        get {
            if let imageView = self.leftView as? UIImageView {
                return imageView.image
            } else {
                return nil
            }
        }
    }
    
    //MARK:- Password accessoryView
    @IBInspectable var secureEntry: UIImage? {
        set{
            if secureEntry != nil {
                let btn = UIButton(frame: CGRect(x: 16, y: 8, width: 24, height: 24))
                let viewRight: UIView = UIView(frame: CGRect.init(x: 0, y: 0, width: 56, height: 40))// set per your requirement
                viewRight.addSubview(btn)
                
                btn.setImage(#imageLiteral(resourceName: "unselected"), for: .normal)
                btn.setImage(#imageLiteral(resourceName: "icon"), for: .selected)
                btn.addTarget(self, action: #selector(accessoryHandler), for: .touchUpInside)
                rightViewMode = .always
                isSecureTextEntry = true
                rightView = viewRight
            } else {
                rightViewMode = .never
                rightView = nil
            }
        }
        get{
            return UIImage()
        }
        
    }
    
    
    @objc private func accessoryHandler(sender: UIButton) {
        sender.isSelected = !sender.isSelected
        self.isSecureTextEntry = !sender.isSelected
    }
}
