//
//  ViewController.swift
//  TabBar
//
//  Created by Aqib Ali on 24/08/19.
//  Copyright © 2019 Aqib Ali. All rights reserved.
//

import UIKit

struct Student:Decodable {
    let name:String?
}


class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

}

class ViewController1: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
}






class TableView<U,T:TableViewCell<U>>: UITableViewController {
    
    var items = Array<U>()
    var heightForRow:CGFloat = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let name = String(describing: T.self)
        let nib = UINib(nibName: name, bundle: Bundle.main)
        tableView.register(nib, forCellReuseIdentifier: name)
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: T.self), for: indexPath) as! TableViewCell<U>
        cell.item = items[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return heightForRow
    }
    
}



class TableViewCell<T:Decodable>: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }
    
    var item:T?
    
}



