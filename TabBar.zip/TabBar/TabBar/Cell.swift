//
//  Cell.swift
//  TabBar
//
//  Created by Aqib Ali on 25/08/19.
//  Copyright © 2019 Aqib Ali. All rights reserved.
//

import UIKit

class Cell: TableViewCell<Student> {
    @IBOutlet weak var label:UILabel!
    override var item: Student?{
        didSet{
            label.text = item?.name
        }
    }
}


